package com.tebogo.markvault.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.tebogo.markvault.AppViewModel
import com.tebogo.markvault.data.NoteMeta

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(vm: AppViewModel, nav: NavController) {
    val libraryUri by vm.libraryUri.collectAsStateWithLifecycle()
    val notes by vm.notes.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    var currentPath by rememberSaveable { mutableStateOf("") }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> if (uri != null) vm.setLibrary(uri) }

    BackHandler(enabled = currentPath.isNotEmpty() && tab == 0) {
        currentPath = currentPath.substringBeforeLast('/', "")
    }

    fun open(n: NoteMeta) {
        vm.openArticle(n.id, n.title)
        nav.navigate("reader") { launchSingleTop = true }
    }

    val folderCounts = remember(notes, currentPath) {
        val prefix = if (currentPath.isEmpty()) "" else "$currentPath/"
        val m = sortedMapOf<String, Int>(String.CASE_INSENSITIVE_ORDER)
        for (n in notes) {
            val f = n.folder
            val child: String? = when {
                currentPath.isEmpty() && f.isNotEmpty() -> f.substringBefore('/')
                currentPath.isNotEmpty() && f != currentPath && f.startsWith(prefix) ->
                    f.removePrefix(prefix).substringBefore('/')
                else -> null
            }
            if (!child.isNullOrEmpty()) m[child] = (m[child] ?: 0) + 1
        }
        m
    }
    val filesHere = remember(notes, currentPath) {
        notes.filter { it.folder == currentPath }.sortedBy { it.title.lowercase() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("\uD83D\uDCDA MarkVault", fontWeight = FontWeight.Bold) },
                actions = {
                    if (libraryUri != null && !progress.running) {
                        IconButton(onClick = { vm.reindex() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Sync library")
                        }
                    }
                    IconButton(onClick = { nav.navigate("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (progress.running) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(
                    "\u23F3 ${progress.phase} ${progress.done} / ${progress.total}",
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            when {
                libraryUri == null -> WelcomeState { picker.launch(null) }
                notes.isEmpty() && !progress.running ->
                    EmptyState(onReindex = { vm.reindex() }, onChange = { picker.launch(null) })
                else -> {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .clickable { nav.navigate("search") }
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Search, contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                "Search ${notes.size} notes\u2026",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    TabRow(selectedTabIndex = tab) {
                        Tab(selected = tab == 0, onClick = { tab = 0 },
                            text = { Text("\uD83D\uDCC1 Browse") })
                        Tab(selected = tab == 1, onClick = { tab = 1 },
                            text = { Text("\uD83D\uDD52 Recent") })
                    }

                    if (tab == 0) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("\uD83C\uDFE0", Modifier.clickable { currentPath = "" }, fontSize = 16.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (currentPath.isEmpty()) vm.libraryName() else "/ $currentPath",
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(folderCounts.keys.toList()) { folder ->
                                RowItem(
                                    emoji = "\uD83D\uDCC1", title = folder,
                                    trailing = "${folderCounts[folder]}",
                                    onClick = {
                                        currentPath = if (currentPath.isEmpty()) folder
                                        else "$currentPath/$folder"
                                    }
                                )
                            }
                            items(filesHere, key = { it.id }) { n ->
                                RowItem(
                                    emoji = "\uD83D\uDCC4", title = n.title,
                                    subtitle = if (n.name != n.title) n.name else null,
                                    onClick = { open(n) }
                                )
                            }
                            item { Spacer(Modifier.height(24.dp)) }
                        }
                    } else {
                        if (recent.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(
                                    "No recently opened notes yet.",
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(Modifier.fillMaxSize()) {
                                items(recent, key = { it.id }) { n ->
                                    RowItem(
                                        emoji = "\uD83D\uDD52", title = n.title,
                                        subtitle = n.folder.ifBlank { null },
                                        onClick = { open(n) }
                                    )
                                }
                                item { Spacer(Modifier.height(24.dp)) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowItem(
    emoji: String,
    title: String,
    subtitle: String? = null,
    trailing: String? = null,
    onClick: () -> Unit
) {
    Column(
        Modifier.fillMaxWidth().clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) { Text(emoji, fontSize = 17.sp) }
            Spacer(Modifier.width(10.dp))
            Text(
                title, Modifier.weight(1f), fontWeight = FontWeight.Medium,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            if (trailing != null) {
                Text(trailing, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (subtitle != null) {
            Text(
                subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 36.dp), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
}

@Composable
private fun WelcomeState(onPick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("\uD83D\uDCDA", fontSize = 64.sp)
        Spacer(Modifier.height(16.dp))
        Text("Welcome to MarkVault", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Choose the folder that holds your Markdown library. " +
                "Everything is indexed and stays 100% on this phone.",
            color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onPick) { Text("\uD83D\uDCC1  Choose library folder") }
    }
}

@Composable
private fun EmptyState(onReindex: () -> Unit, onChange: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("No .md files indexed yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onReindex) { Text("\u21BB  Index now") }
        Spacer(Modifier.height(12.dp))
        Text(
            "\uD83D\uDCC1 Choose a different folder",
            Modifier.clickable(onClick = onChange).padding(8.dp),
            color = MaterialTheme.colorScheme.primary
        )
    }
}
